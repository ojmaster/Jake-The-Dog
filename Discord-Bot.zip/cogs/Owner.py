import discord
from discord.ext import commands
import time
import asyncio

intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)
client = discord.Client()

class Owner(commands.Cog):

  def __init__(self, bot):
    self.bot = bot

  @commands.command()
  async def changepresence(self, ctx):
    embed = discord.Embed(title = "What would you like to change the presence to?", color = discord.Color.gold())
    embed.add_field(name = "Watching", value = ":one:", inline = True)
    embed.add_field(name = "⠀", value = "⠀")
    embed.add_field(name = "Listening", value = ":two:", inline = True)
    embed.add_field(name = "Streaming", value = ":three:", inline = True)
    embed.add_field(name = "⠀", value = "⠀")
    embed.add_field(name = "Playing", value = ":four:", inline = True)
    msg = await ctx.send(embed = embed)
    await msg.add_reaction("1️⃣")
    await msg.add_reaction("2️⃣")
    await msg.add_reaction("3️⃣")
    await msg.add_reaction("4️⃣")

    def check(msg):
      return msg.author == ctx.author and msg.channel == ctx.channel
      msg.content.lower() in ["1", "2", "3", "4"]

    msg = await client.wait_for("message", check=check)
    if msg.content() == "1":
        await ctx.send("You said 1")
    elif msg.content() == "2":
        await ctx.send("You said 2")
    elif msg.content() == "3":
        await ctx.send("You said 3")
    elif msg.content() == "4":
        await ctx.send("You said 4")


def setup(bot):
	bot.add_cog(Owner(bot))