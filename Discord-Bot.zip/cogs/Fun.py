import discord
from discord.ext import commands
from discord.ext.commands import has_permissions
import time
import random
import http
from urbandictionary_top import udtop
import  aiohttp


intents = discord.Intents.all()
bot = commands.Bot(command_prefix='!', intents=intents)
client = discord.Client()

class Fun(commands.Cog):
  """
  Its fun time!
  """
  def __init__(self, bot):
    self.bot = bot

  @commands.command()
  @has_permissions(manage_messages=True, ban_members=True)
  async def surprise(self, ctx):
    """A lil surprise fun"""
    f = open("beemovie.txt", 'r')
    for word in f:
      await ctx.send(word)
      time.sleep(0.15)

  @commands.command()
  async def rule34(self, ctx):
    """Horny Time"""
    await ctx.send(file = discord.File('./Bonk/bonk.jpg'))

  @commands.command(aliases=["slots", "bet"])
  @commands.cooldown(rate=1, per=3.0, type=commands.BucketType.user)
  async def slot(self, ctx):
      """ Roll the slot machine """
      emojis = "🍎🍊🍐🍋🍉🍇🍓🍒"
      a = random.choice(emojis)
      b = random.choice(emojis)
      c = random.choice(emojis)

      slotmachine = f"**[ {a} {b} {c} ]\n{ctx.author.name}**,"

      if (a == b == c):
          await ctx.send(f"{slotmachine} All matching, you won! 🎉")
      elif (a == b) or (a == c) or (b == c):
          await ctx.send(f"{slotmachine} 2 in a row, you won! 🎉")
      else:
          await ctx.send(f"{slotmachine} No match, you lost 😢")

  @commands.command(name="8ball")
  async def eightball(self, ctx, question):
    """Consult the wise master for the answer to your questions"""
    responses = ["As I see it, yes", "Yes", "No", "Very likely", "Not even close", "Maybe", "Very unlikely", "Ur mom told me yes", "Ur mom told me no", "Ask again later", "Better not tell you now", "Concentrate and ask again", "Don't count on it", " It is certain", "My sources say no", "Outlook good", "You may rely on it", "Very Doubtful", "Without a doubt"]
    response = random.choice(responses)
    await ctx.send(response)

  @commands.command(aliases=["flip", "coin"])
  async def coinflip(self, ctx):
      """ Coinflip! """
      coinsides = ["Heads", "Tails"]
      await ctx.send(f"**{ctx.author.name}** flipped a coin and got **{random.choice(coinsides)}**!")
  
  @commands.command()
  async def urban(self, ctx, *, search):
      """ Find the 'best' definition to your words """
      term = udtop(search)
      search = search.capitalize()
      embed = discord.Embed(title = f'__{search}__', description = term, color=discord.Color.purple())
      await ctx.send(embed = embed)

  @commands.command(aliases=['cat','randomcat'])
  async def cats(self, ctx):
      '' 'Random cats pictures nyan ~' ''
      #http: //discordpy.readthedocs.io/en/latest/faq.html#what-does-blocking-mean
      async  with  aiohttp.ClientSession () as  cs :
          async  with  cs.get('http://aws.random.cat/meow') as r:
              res = await r.json()
              await  ctx.send(res['file'])


  @commands.command()
  async def pick(self, ctx, *arg):
    choices = list(arg)
    choices.pop(0)
    await ctx.send(f'{random.choice(choices)}')
    return

def setup(bot):
	bot.add_cog(Fun(bot))